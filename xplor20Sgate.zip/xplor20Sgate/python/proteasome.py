#!/usr/bin/python

__doc__ = """The functions in this module help in calculating the structure of the proteasomal gate."""
__author__ = "Tomasz Religa <religa@pound.med.utoronto.ca>"
__version__ = "0.1"
__date__ = "2009-06-10"
__copyright__ = "Tomasz Religa"
__license__ = "GPL"

import xplor
from atomSel import AtomSel

command = xplor.command
xc=xplor.command



nterm = AtomSel("resi 97:106")
nterm_all = AtomSel("resi 97:113")
alpha = AtomSel("resi 114:333 and segid A:G")
alpha_sl = AtomSel("(resi 114:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N or name HA or name CB))")
alpha_allsl = AtomSel("(resi 114:333 and segid A:G) or (segid 1:7)")


def constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1, vdw2=10):
    xc("""constraints 
 fix (resi 114:333 and segid A:G) 
 fix (segid 1:7 and (name CA or name C or name N or name HA or name CB))
end 
constraints 

! Spin label should steer clear of the alpha subunit
 interaction (segid 1:7) 
 ((resi 97:118 or resi 122:170 or resi 174:193 or resi 197:205 or resi 209:213 or resi 217:241 or resi 245:333) 
 and (name CA or name C or name N or name HA or name HA* or name HN or name O or name CB or name HB*)
 and segid A:G) weights vdw 10 end 

!
! and (name CA or name C or name N or name HA or name HA* or name HN or name O or name CB or name HB*)
! Spin label should maintain all its bond / angles and impropers
 interaction (segid 1:7 and resi 120) (segid 1:7 and resi 120)  weights * 1 end 
 interaction (segid 1:7 and resi 172) (segid 1:7 and resi 172)  weights * 1 end 
 interaction (segid 1:7 and resi 195) (segid 1:7 and resi 195)  weights * 1 end 
 interaction (segid 1:7 and resi 207) (segid 1:7 and resi 207)  weights * 1 end 
 interaction (segid 1:7 and resi 215) (segid 1:7 and resi 215)  weights * 1 end 
 interaction (segid 1:7 and resi 243) (segid 1:7 and resi 243)  weights * 1 end 

! Ntermini shouldn't bump into each other
 interaction (resi 97:114) (resi 97:114) weights bond %.2f angle %.2f impr %.2f vdw %.2f end 
! Or into the alpha subunit
 interaction (resi 97:113) (resi 114:333) weights vdw %.2f end 

end"""%(bond,angle,impr,vdw, vdw2))
#    print "noe.scale =", noe.scale()
    pass

def writeStruct(name="out.pdb"):
    xc("write coor output = %s end"%(name))
    pass













def NOEGen(i, noe, inList):
    """This function generates NOE potential for 'i' number of 'in' n-termini. 

It saves the result in a global variable 'noe'."""
    from random import sample
    from noePotTools import create_NOEPot
    #global noe
    #global inList
    files = ["input/methyl/M40.tbl"]
    if i==0:
        inList = ""
    elif i==7: 
        inList =  "ABCDEFG"
    else:
        inList = ["B"]
        inList.extend(sample("CDEFG", i-1))
    for chain in "ABCDEFG":
        if chain in inList:
            # Add the potential for the 'in' guy 
            files.append("input/methyl/IN.%s.tbl"%(chain))
        else:
            # Add the potential for the 'out' guy
            files.append("input/methyl/OUT.%s.tbl"%(chain))
    # Now discard the old NOE potential and generate the new NOE one:
    pot = create_NOEPot('methyl', files)
    pot.setScale(1)
    noe = [pot]
    pass



if __name__=='__main__':
    pass

### Local Variables: ***
### py-indent-offset: 4 ***
### mode: font-lock ***
### End: ***


