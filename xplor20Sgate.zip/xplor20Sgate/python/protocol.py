"""high-level initialization routines.

These routines provide high level interfaces to initialize potential terms
and to set up minimization and dynamics calculations.
"""
from atomSel import AtomSel

#default topology/parameter files
parameters={}
parametersInitialized={}
topology={}
topologyInitialized={}
topparVersion={}

parameters['protein'] = "protein.par"
parametersInitialized['protein']=[]
topology['protein'] = "protein.top"
topologyInitialized['protein']=[]

parameters['nucleic'] = "nucleic.par"
parametersInitialized['nucleic']=[]
topology['nucleic'] = "nucleic.top"
topologyInitialized['nucleic']=[]

parameters['water'] = "tip3p.parameter"
parametersInitialized['water']=[]
topology['water'] = "tip3p.topology"
topologyInitialized['water']=[]

#pseudo-atoms for rdc, pre, etc pots.
parameters['axis'] = "axes.par"
parametersInitialized['axis']=[]

from regularize import fixupCovalentGeom, covalentMinimize, addUnknownAtoms
from regularize import CovalentViolation

def initRandomSeed(seed=None):
    """set the initial random seed. If the seed argument is omitted, it is set
    to seconds from the epoch mod 10^7
    """
    if globals().has_key('initialRandomSeed_'):
        raise Exception("random seed already initialized")
    global initialRandomSeed_
    import time
    if seed==None:
        seed = int(time.time() % 1e7)
        import xplor
        seed = xplor.p_comm.distribute(seed)
        pass
    initialRandomSeed_ = seed
    import simulationWorld
    simWorld = simulationWorld.SimulationWorld_world()
    simWorld.setRandomSeed( initialRandomSeed_ )
    if simWorld.logLevel() != 'none':
        print "random seed initialized to ", initialRandomSeed_
        pass
    return

def initialRandomSeed():
    """return the initial random seed value, or that from
    <m simulationWorld>.random if initRandomSeed has not been called.
    """
    if globals().has_key('initialRandomSeed_'):
        return initialRandomSeed_
    else:
        import simulationWorld
        simWorld = simulationWorld.SimulationWorld_world()
        return simWorld.random.seed()
    pass

def genTopParFilename(filename,
                      useTopParVar=False):
    """
    If the given filename exists, it is returned, else the file is
    looked for the in the TOPPAR directory, and a full path is returned
    if it is found there.

    If useTopParVar=True, the XPLOR TOPPAR variable is used for the
    filename (instead of expanding its value). This results in
    shorter paths, but the path is only valid within the XPLOR interpreter.
    """
    import os
    from os import environ as env
    if os.access(filename,os.F_OK):
        pass
    elif os.access(env['TOPPAR'] + '/' + filename,os.F_OK):
        if useTopParVar:
            filename = 'TOPPAR:' + filename
        else:
            filename = env['TOPPAR'] + '/' + filename
            pass
    else:
        mess = """initTopology: could not find name %s as a structure type
                  or as file in the current dir, or in TOPPAR""" % filename
        raise Exception(mess)
    return filename
            

from xplorSimulation import getXplorSimulation    

def initParams(files,
               reset=0,
               weak_omega=0,
               simulation=0):
    """file is a structure type or filename or a list of a combination of
    these two.

    valid structure types are: protein, nucleic, and water

    The default protein, nucleic and water parameter files are specified in
    the protocol.parameters dictionary. Default values can be modified from
    a script using e.g.
       import protocol
       protocol.parameters['protein'] = '/path/to/other/file.par' 

    If the argument is a filename, the current directory is first searched
    for the file, and then the TOPPAR directory is searched.
    XPLOR parameters are documented <l http://nmr.cit.nih.gov/xplor-nih/xplorMan/node49.html
    here>.
    If reset is true, all previous parameter settings are discarded
    If weak_omega is true, improper force constants associated with the
    peptide bond are reduced by 1/2 to allow a small amount of flexibility.
    """
    import os
    from os import environ as env

    xSim = getXplorSimulation(simulation)
    command = xSim.command
    simName = xSim.name()

    if reset:
        command("param reset end")
        command("eval ($edtaParamsInit=FALSE)")
        command("eval ($ionParamsInit=FALSE)")
        for key in parametersInitialized.keys():
            if simName in parametersInitialized[key]:
                parametersInitialized[key].remove(simName)
                pass
            pass
        pass

    if weak_omega:
        command('eval ($weak_omega=1)')

    def addParams(file):
        versionName=""
        if parameters.has_key(file):
            if simName in parametersInitialized[file]: return
            parametersInitialized[file].append(simName)
            versionName=file
            file = parameters[file]
            pass

        file = genTopParFilename(file,True)
            
        varName=''
        if versionName:
            varName="%s_toppar_vers"%versionName
            pass
        (version) =command("param @%s end" %file,varName)
        if versionName:
            #FIX: check for mismatch
            topparVersion[versionName] = version[0]
            pass
        return


    if type(files)==type("string"):
        files=[files]
        pass
    for file in files:
        addParams(file)
        pass
    return

def initTopology(files=[],
                 reset=0,
                 simulation=0):
    """file is a structure type or filename or a list of a combination of
    these two.

    valid structure types are: protein, nucleic, and water

    The default protein, nucleic and water topology files are specified in
    the protocol.topology dictionary. Default values can be modified from
    a script using e.g.
       import protocol
       protocol.topology['protein'] = '/path/to/other/file.top' 

    First the current directory is searched for the file, and then TOPPAR
    is searched.
    XPLOR topology is documented <l http://nmr.cit.nih.gov/xplor-nih/doc/current/xplor/node46.html
    here>.
    If reset is true, all previous topology settings are discarded
    """
    import os
    from os import environ as env

    xSim = getXplorSimulation(simulation)
    command = xSim.command
    simName = xSim.name()

    if reset:
        command("rtf reset end")
        command("eval ($ionTopoInit=FALSE)")
        for key in topologyInitialized.keys():
            if simName in topologyInitialized[key]:
                topologyInitialized[key].remove(simName)
            pass
        pass


    def addTopology(file):
        versionName=""
        if topology.has_key(file):
            if simName in topologyInitialized[file]: return
            topologyInitialized[file].append(simName)
            versionName=file
            file = topology[file]
            pass

        file = genTopParFilename(file,True)

        varName=''
        if versionName:
            varName="%s_toppar_vers"%versionName
            pass
        (version) = command("rtf @%s end" %file,varName)
        if versionName:
            #FIX: check for mismatch
            topparVersion[versionName] = version[0]
            pass
        return


    if type(files)==type("string"):
        files=[files]
        pass
    for file in files:
        addTopology(file)
        pass
    return

def initStruct(files=0,
               erase=1,
               simulation=0):
    """read XPLOR PSF files.

    the file argument is a filename or list of filenames to read.
    First the current directory is searched for the file, and then TOPPAR
    is searched. Alternatively, a psf entry (starting with PSF...) can be
    directly passed as the files argument.

    Any pre-existing structure information is erased unless the erase argument
    is cleared. 
    """
    xSim = getXplorSimulation(simulation)
    command = xSim.command

    if erase: command("struct reset end")

    if not files: return
    
    import re, os
    done=False
    if type(files)==type("string"):
        if re.search("PSF\s*\n",files):
            command("struct %s end" % files)
            done=True
        else:
            files=[files]
            pass
        pass
    if not done:
        for file in files:
            try:
                os.stat(file)
                command("struct @%s end" %file)
            except OSError:
                from os import environ as env
                tfile = env['TOPPAR'] + '/' + file
                try:
                    os.stat(tfile)
                    command("struct @TOPPAR:%s end" %file)
                except OSError:
                    raise Exception("initStruct: could not find file " + file +\
                                    " in current dir, or in TOPPAR")
                pass
            pass
        pass
    updatePseudoAtoms()
    return

pdbLocation="ftp://ftp.wwpdb.org/pub/pdb/data/structures/divided/pdb/"

def downloadPDB(entry):
    """download a compressed PDB file from the RCSB database
    return the PDB record as a string.
    """

    entry = entry.lower()

    if len(entry)!=4:
        raise Exception("entry must be a 4 character string:" + `entry`)

    middle = entry[1:3]

    url = pdbLocation + middle + '/pdb' + entry + '.ent.gz'

    import urllib2
    import time
    connectAttempts=3
    for attempt in range(connectAttempts):
        try:
            u=urllib2.urlopen(url)
            contents=u.read()
            u.close()
            break
        except IOError, err:
            print 'sleeping...'
            time.sleep( 3 ) # secs -
            pass
        pass
    else:
        raise Exception("error fetching %s: %s"%(url,err.message)+
                        `err.args`)
    
    from StringIO import StringIO
    import gzip
    ret=gzip.GzipFile(fileobj=StringIO(contents)).read()

    return ret

def loadPDB(file='',
            string='',
            entry='',
            model=-1,
            simulation=None,
            deleteUnknownAtoms=False,
            verbose=-1):
    """load a PDB entry from file, string, or from the RCSB database.
    autogenerate the psf and initialize coordinates.

    deleteUnknownAtoms is passed to initCoords()

    A side-effect is that protein or nucleic covalent force field parameters
    are loaded by initParams()
    """

    sim = simulation
    import simulation
    if sim:
        oldCurrentSimulation = simulation.currentSimulation()
        simulation.makeCurrent(sim)
        pass

    
    def finalize():
        if sim:
            simulation.makeCurrent(oldCurrentSimulation)
            pass
        return

    logfile=open("/dev/null","w",0)
    from simulationWorld import world
    import sys
    if verbose<0 and world().logLevel()!="none": verbose=True
    if verbose==True: logfile=sys.stdout

    if file:
        print >>logfile,'loading pdb file: %s ' % file, ; logfile.flush()
        pdbEntry = open(file).read()
    elif string:
        pdbEntry = string
    elif entry:
        print >>logfile,'loading pdb entry: %s ' % entry, ; logfile.flush()
        
        pdbEntry = downloadPDB(entry)

        print >>logfile,' [downloaded]', ; logfile.flush()
    else:
        raise Exception("entry or file argument must be specified.")
        
    
    import psfGen
    psfGen.pdbToPSF(pdbEntry)

    print >>logfile,' [psf]', ; logfile.flush()

    try:
        ret=initCoords(string=pdbEntry,model=model,verbose=verbose,
                       deleteUnknownAtoms=deleteUnknownAtoms)
    except:
        finalize()
        raise

    print >>logfile,' [coords]'

    finalize()

    return ret



class InitCoordsResult:
    """ A class to simplify returning B factors and occupancies read
    during a call to initCoords """
    def __init__(self):
        self.bfactors = []
        self.occupancies = []
        pass
    pass


def initCoords(files=[],string="",
               model=-1,
               verbose=-1,
               erase=False,
               useChainID=True,
               correctSymmetricSidechains=True,
               strictResNames=False,
               maxUnreadEntries=(20,0.2),
               deleteUnknownAtoms=False,
               selection="all"):
    """
    Initialize coordinates from one of more pdb file,
      or from a string containing a PDB entry.

    if model is specified, the specified PDB MODEL record will be read.

    if erase is set to True, then atom positions in selection are cleared
    before reading the pdb record.

    If useChainID is True (the default), then the the chain ID PDB field is
    used as the segment name (if set), If the chain ID field is blank it is
    ignored regardless.

    If deleteUnknownAtoms is True, then atoms whose coordinates are still
    unknown after the PDB file is read will be deleted
    
    If correctSymmetricSidechains is True (the default), then the sidechains
    of phe, tyr, asp, and glu residues are checked to ensure that their
    symmetric torsion angles (chi3 for glu, chi2 for the rest) are in
    the correct (0..180 degree) range. If they are incorrect, then atomic
    positions are swapped using <m selectTools>.correctSymmetricSidechains.

    If strictResNames is True, then residue names in the PDB must match
    those in the PSF, otherwise, the residue names need not match
    and backbone atoms for mutants can be read. Note that sidechain atoms (or
    base atoms in nucleic acids) may be strangely placed if this option is
    False.

    PDB ATOM records which do not exactly match the expected input (the
    atom name is not exactly the same) are attempted to be matched using the
    function matchInexactAtomEntry. If more than maxUnreadEntries[0] or
    maxUnreadEntries[1]*(num atoms) unmatchable ATOM records are
    encountered, an exception is thrown. This check is disabled (no exception
    will be thrown) if maxUnreadEntries is set to None.
    """

    from selectTools import convertToAtomSel
    selection = convertToAtomSel(selection)
    
    xSim = getXplorSimulation(selection.simulation())
    command = xSim.command

    if verbose<0:
        verbose=0
        import simulationWorld
        simWorld = simulationWorld.SimulationWorld_world()
        if simWorld.logLevel() != 'none':
            verbose=1
            pass
        pass

    if erase:
        # FIX: this should be an option to PDBTool::read
        command("coor INIT SELE=(%s) end"%selection.string())
        pass
        
    

    if type(files)==type("string"):
        files=[files]
        pass

    if not files and not string:
        print "initCoords: warning no file or string was specified."
    
    from pdbTool import PDBTool
    pdb = PDBTool("",selection,useChainID,strictResNames)
    pdb.setVerbose(verbose)

    unknownEntries=[]
    for file in files:
        pdb.setFilename(file)
        unknownEntries += pdb.read(model)
        pass

    if string:
        pdb.setFilename('')
        pdb.setContents(string)
        unknownEntries += pdb.read(model)
        pass

    unreadEntries=0
    for entry in unknownEntries:
        if not matchInexactAtomEntry(entry,pdb,selection,
                                     strictResNames,verbose):
            unreadEntries += 1
            pass
        pass

    if maxUnreadEntries != None:
        if (unreadEntries>maxUnreadEntries[0] and
            unreadEntries>maxUnreadEntries[1]*len(selection)):
            raise Exception("too many unreadable ATOM entries: %d" %
                            unreadEntries)
    
    if verbose:
        if unreadEntries:
            print "initCoords: unable to read %d pdb ATOM entries" % \
                  unreadEntries,
            print " (nonpseudoatom)"
            pass
        unknown = AtomSel("not known")
        if len(unknown):
            print "initCoords: still %d unknown atomic coordinates" % \
                  len(unknown)
            pass
        pass

    if correctSymmetricSidechains:
        from selectTools import correctSymmetricSidechains
        correctSymmetricSidechains(sim=xSim)
        pass
            
    retVal = InitCoordsResult()

    retVal.bfactors = pdb.bfactors()
    retVal.occupancies = pdb.occupancies()


    if deleteUnknownAtoms:
        unknown = AtomSel("not known")
        if verbose and len(unknown):
            print "initCoords:  Deleting %d atoms with unknown coordinates."  % len(unknown)
            pass

        retVal.bfactors    = syncArrayBeforeDelete(retVal.bfactors, unknown)
        retVal.occupancies = syncArrayBeforeDelete(retVal.occupancies, unknown)
        command("delete sele (not known) end")
        pass

    return retVal


def syncArrayBeforeDelete(anArray, selectionToDelete):
    """ Given an array of values indexed by atom number, and a selection of
    atoms to be deleted, remove the entries in the array so that they will
    match up with the correct atoms after the atoms are actually deleted """

    if len(anArray) != selectionToDelete.simulation().numAtoms():
        raise 'array size (%d) != number of atoms in simulation (%d)' % \
              (len(anArray), selectionToDelete.simulation().numAtoms())
    
    newArray = []

    for c in range(len(anArray)):
        if not selectionToDelete.containsIndex(c):
            newArray.append(anArray[c])
            pass
        pass
    
    return newArray

def addPseudoResName(resname):
    """
    Add a residue name to the set which correspond to pseudo atoms.
    """
    pseudoResNames.add(resname)
    return
    
def updatePseudoAtoms(simulation=0):
    """
    Update the set of pseudo atoms selected by the PSEUdo atom selection
    keyword.
    """

    xSim = getXplorSimulation(simulation)
    command = xSim.command


    outputState=xSim.disableOutput()
   
    for resname in pseudoResNames:
        command("vector iden (pseudo) (pseudo or (resname %s))" % resname)
        pass
    xSim.enableOutput(outputState)
    return

    
# residue names of pseudo atoms which may or may not be present
# in a coordinate record.
pseudoResNames=set()
import varTensorTools    #import modules to populate pseudoResNames
import diffPotTools
import prePotTools
import planeDistTools

def matchInexactAtomEntry(entry,pdbTool,selection,strictResNames,verbose=0):
    """ try to match a PDB record to an atom if the name is not exactly the
    same. The coordinates will only be overwritten if they are unknown.

    The current algorithm for matching is as follows:
      match H to HT1 
      else match if there's only a single undefined atom whose name starts
      with the same character.
      else
      match if atom names start with the same character and the remainder
      of the characters are simple tranpositions of each other.
      else
      match if there's only a single undefined atom whose name starts
      with and ends with the same character.
      else
      match if the first name of the name is a digit present in the correct
      atom name and the second character matches the first character of the
      correct name.
      else
      match if the two names have two matching characters.
      else
      match up   O --> OT1
               OXT --> OT2

      If the match is not unique, it is not made.

    The residue number and segment id must match.

    Entries with nonnumeric residue numbers are ignored.

    For atoms with residue names corresponding to those of pseudo atoms
    (e.g. ANI), this function prints a warning on missing atoms, but returns
    a True value.

    If strictResNames is True, then residue names in the PDB must match
    those in the PSF (default), otherwise, the residue names need not match
    and backbone atoms for mutants can be read. Note that sidechain atoms (or
    base atoms in nucleic acids) may be strangely placed if this option is
    False.

    """
    serial     = entry[ 6 :12]
    name       = entry[ 12:16]
    altLoc     = entry[ 16:17]
    resName    = entry[ 17:20]
    chainID    = entry[ 21:22]
    try:
        resid  = entry[ 22:26]
    except ValueError:
        if verbose: print 'nonnumeric residue number:' ,entry
        return 1
    resSeq     = entry[ 22:26]
    iCode      = entry[ 26:27]
    x  	       = float(entry[ 30:38])
    y  	       = float(entry[ 38:46])
    z  	       = float(entry[ 46:54])
    occupancy  = entry[ 54:60]
    tempFactor = entry[ 60:66]
    segID      = entry[ 72:76]
    element    = entry[ 76:78]
    charge     = entry[ 78:80]

    if pdbTool.useChainID():
        if chainID!=' ': segID = chainID+'   '
        pass

    readAtoms = pdbTool.readAtoms()

    name = name.strip()
    from atomSel import AtomSel, intersection
    resAtoms = intersection(selection,
                            AtomSel('not known and (resid %s and segid "%s")' %
                                    (resSeq,segID) ))
    resAtoms = filter(lambda a: not readAtoms[a.index()], resAtoms)
    matchAtom=None

    from psfGen import renameResidues
    resName = renameResidues([resName])[0]
    if strictResNames and resAtoms:
        recResName = resAtoms[0].residueName()
        if recResName != resName:
            raise Exception("residue name mismatch %s != %s\n" % (resName,
                                                                  recResName)+
                            "  entry:" + entry)
        pass

    if not matchAtom:
        hn = filter(lambda a:a.atomName()=="HN",resAtoms)
        if hn and name=='H':
            matchAtom = hn[0]
            pass
        pass    
    if not matchAtom:
        ht1 = filter(lambda a:a.atomName()=="HT1",resAtoms)
        if ht1 and (name=='H1' or name=='H2'):
            matchAtom = ht1[0]
            pass
        pass    
    if not matchAtom:
        ht2 = filter(lambda a:a.atomName()=="HT2",resAtoms)
        if ht2 and name=='H3':
            matchAtom = ht2[0]
            pass
        pass    
    if not matchAtom:
        # match atom name that begin with same character
        for atom in resAtoms:
            if atom.atomName().startswith(name[0]):
                #check for names with transposed characters
                if set(atom.atomName()) == set(name):
                    matchAtom = atom
                    break
                elif matchAtom:   #if two match, then none match
                    matchAtom = None
                    break
                else:
                    matchAtom = atom
                    pass
                pass
            pass
        pass
    if not matchAtom:
        # match atom name that begin and end with same character
        atom = filter(lambda a: (a.atomName()[0] ==name[0] and
                                 a.atomName()[-1]==name[0-1] ) , resAtoms)
        if len(atom)==1:
            matchAtom = atom[0]
            pass
        pass
    if not matchAtom:
        for atom in resAtoms:
            if ((name[0].isdigit() and atom.atomName().find(name[0])>=0) and
                name[1] == atom.atomName()[0]):
                if matchAtom:
                    matchAtom = None
                    break
                else:
                    matchAtom = atom
                    pass
                pass
            pass
        pass
    if not matchAtom:
        for atom in resAtoms:
            count=0
            for c in atom.atomName():
                if name.find(c)>=0: count += 1
                pass
            if count>=2:
                if matchAtom:
                    matchAtom = None
                    break
                else:
                    matchAtom = atom
                    pass
                pass
            pass
        pass
    #rules for strange nucleic base HN atom naming
    if not matchAtom and name=="HN'":
        h21 = filter(lambda a:a.atomName()=="H21",resAtoms)
        h41 = filter(lambda a:a.atomName()=="H41",resAtoms)
        h61 = filter(lambda a:a.atomName()=="H61",resAtoms)
        if h21 and not readAtoms[h21[0].index()]:
            matchAtom = h21[0]
        elif h41 and not readAtoms[h41[0].index()]:
            matchAtom = h41[0]
        elif h61 and not readAtoms[h61[0].index()]:
            matchAtom = h61[0]
            pass
        pass
        

    #special rules for the O-terminus
    if not matchAtom:
        ot1 = filter(lambda a:a.atomName()=="OT1",resAtoms)
        if name=='O' and ot1 and not readAtoms[ot1[0].index()]:
            matchAtom = ot1[0]
            pass
        pass
    if not matchAtom:
        ot2 = filter(lambda a:a.atomName()=="OT2",resAtoms)
        if name=='OXT' and ot2 and not readAtoms[ot2[0].index()]:
            matchAtom = ot2[0]
            pass
        pass

    if not altLoc in pdbTool.allowedAltLoc():
        matchAtom=False

    if matchAtom:
        if verbose:
            print "matchInexactAtomEntry:", \
                  "matching entry %s %s %s to atom %s %s %s" % \
                  (segID,resSeq,name,
                   matchAtom.segmentName(),matchAtom.residueNum(),
                   matchAtom.atomName())
                                                                
        matchAtom.setPos( [x,y,z] )
        try:
            occupancy = float(occupancy)
        except ValueError:
            occupancy = 0
            pass
        try:
            tempFactor = float(tempFactor)
        except ValueError:
            tempFactor = 0
            pass
        pdbTool.setAux1(matchAtom, occupancy)
        pdbTool.setAux2(matchAtom, tempFactor)
        pass
    else:
        if verbose:
            print "matchInexactAtomEntry:", \
                  "found no match for entry %s %s %s" % (segID,resSeq,name)
            pass
#            print "matchInexactAtomEntry:", \
#                  "found no match for entry %s %s %s %s" % (segID,resSeq,resName,
#                                                            name)
        pass

    if resName in pseudoResNames:
        if verbose: print " pseudo atom"
        matchAtom=True
        pass        
    
    return matchAtom != None

def addDisulfideBond(sel1,sel2):
    """
    deprecated. Calls psfGen.addDisulfideBond
    """
    import psfGen
    return psfGen.addDisulfideBond(sel1,sel2)
                  
def initNBond(cutnb=4.5,
              rcon=4.0,
              nbxmod=3,
              selStr="known",
              tolerance=0.5,
              repel=0.8,
              onlyCA=0,
              simulation=0):
    """standard initialization of the non-bonded repel potential. The XPLOR
    nonbonded potential term is described <l http://nmr.cit.nih.gov/xplor-nih/xplorMan/node117.html
    here>

    note that cutnb should be greater than rmax + 2*tolerance, where rmax
    is the largest vdw radius.

    selStr specifies which atoms to use in nonbonded energy calculations.
    
    If onlyCA is True, this string gets set to "name CA" - but this option is
    deprecated.
    """

    noSelStr="pseudo" #exclude these nonbonded interactions

    if onlyCA: selStr="name CA"

    xSim = getXplorSimulation(simulation)

    xSim.command("""     
          constraints
            interaction (%s and (not (%s))) (%s and (not (%s)))
            weights * 1 vdw 1 end 
            interaction  (not (%s) and (not (%s))) (not (%s))
            weights * 1 vdw 0 end 
          end""" % (selStr,noSelStr,selStr,noSelStr,selStr,noSelStr,noSelStr) )

        
    xSim.command("""
    parameters
    nbonds
    atom
    nbxmod %d
    wmin  =   0.001  ! warning off
    cutnb =   %f   ! nonbonded cutoff
    tolerance %f
    repel=    %f   ! scale factor for vdW radii = 1 ( L-J radii)
    rexp   =  2     ! exponents in (r^irex - R0^irex)^rexp
    irex   =  2
    rcon=%f      ! actually set the vdW weight
    end
    end 
    """ % (nbxmod,cutnb,tolerance,repel,rcon) )

def initRamaDatabase(type='protein',
                     simulation=0):
    """standard initialization of the <l http://nmr.cit.nih.gov/xplor-nih/xplorMan/node390.html
    rama torsion-angle database potential>.
    """
    xSim = getXplorSimulation(simulation)
    outputState=xSim.disableOutput()
    xSim.command("""
    eval ($krama=1.)
    rama
    nres=30000
    end
    """)
    #print "Tomek: Blah 1", outputState
    #xSim.enableOutput(outputState)
    #xSim.enableOutput()
    if type=='protein':
        xSim.command("""
        rama
        @QUARTS:2D_quarts_new.tbl
        @QUARTS:3D_quarts_new.tbl
        @QUARTS:forces_torsion_prot_quarts_intra.tbl
        end
        @QUARTS:setup_quarts_torsions_intra_2D3D.tbl
        """)
        xSim.enableOutput(outputState)
        #print "Tomek: Blah 2"
    elif type=='nucleic':
        xSim.command("""
        evaluate ($knuc=1.0)
        rama
        @QUARTS:nucleic_deltor_quarts2d.tbl
        @QUARTS:nucleic_deltor_quarts3d.tbl
        @QUARTS:nucleic_deltor_quarts4d.tbl
        @QUARTS:force_nucleic_quarts2d.tbl
        @QUARTS:force_nucleic_quarts3d.tbl
        @QUARTS:force_nucleic_quarts4d.tbl
        end
        @QUARTS:setup_nucleic_2d3d.tbl
        @QUARTS:setup_nucleic_4d.tbl
        """)
        xSim.enableOutput(outputState)
    else:
        xSim.enableOutput(outputState)
        raise Exception("initRamaDatabase: unknown database type: "+ type)
    
    #print "Tomek: Blah 3"
    return


def initDihedrals(filenames=[],
                  string="",
                  scale=1,
                  useDefaults=1,
                  simulation=0):
    """initialize the XPLOR <l http://nmr.cit.nih.gov/xplor-nih/xplorMan/node376.html
    restraints dihe (CDIH) potential term>.

    parameters are:
       filenames   - either a single filename, or a sequence of filenames of
                     dihedral restraint assignment tables.
       string      - assignment table as a plain string.
       scale       - scale factor (defaults to 1).
       useDefaults - use the default sidechain restraints (default: TRUE)
                     these force chi2 angles of PHE, TYR, ASP, and chi3 of GLU
                     to obey IUPAC naming conventions.
    """

    xSim = getXplorSimulation(simulation)

    outputState=xSim.disableOutput()
    xSim.enableOutput(outputState)
    xSim.command("""
    restraints dihed 
    reset
    scale %f
    nass = 10000
    end""" % scale)
    if type(filenames)==type("string"): filenames = [filenames]
    for file in filenames:
        xSim.command("restraints dihed @%s end" % file)
        pass
    if string:
        xSim.command("restraints dihed %s end" % string)
    if useDefaults:
        xSim.command("""
!
! phe_angles.tbl
!
! constrains the chi2 angles of phe, tyr, asp, and glu
! in a protein to -90..90. This so that the dihedral angles follow
! IUPAC naming convention Biochemistry 9, 3471 (1970).
!
! JJK 3/10/97
!

for $res in id (name ca and (resn phe or resn tyr)) loop ang

   restraints dihedral 
      assign 
         (byresidue id $res and name ca)
         (byresidue id $res and name cb)
         (byresidue id $res and name cg)
         (byresidue id $res and name cd1)
         1.0 0.0 90.0 2
   end

end loop ang

for $res in id (name ca and resn asp) loop ang

   restraints dihedral 
      assign 
         (byresidue id $res and name ca)
         (byresidue id $res and name cb)
         (byresidue id $res and name cg)
         (byresidue id $res and name od1)
         1.0 0.0 90.0 2
   end

end loop ang

for $res in id (name ca and resn glu) loop ang

   restraints dihedral 
      assign 
         (byresidue id $res and name cb)
         (byresidue id $res and name cg)
         (byresidue id $res and name cd)
         (byresidue id $res and name oe1)
         1.0 0.0 90.0 2
   end

end loop ang
""")
        pass
    xSim.enableOutput(outputState)
    return

def initCollapse(sel    ="all",
                 Rtarget=-1,
                 scale  =1):
    """initialize the XPLOR <l http://nmr.cit.nih.gov/xplor-nih/xplorMan/node393.html
    radius of gyration potential term>.

    parameters are:
       sel - string or atom selection specifying atoms in include in the
             Rgyr calculation. If this is omitted, all atoms are included.
       Rtarget - target radius. If this is omitted, the target Rgyr is
                 calculated as
                    Rgyr = 2.2*numResidues^0.38 -1 [angstrom]
      scale - scale factor. If omitted, it defaults to 1. Note that the
              per-assignment scale is always 100, so the energy is actually
              scaled by 100*scale.
    """

    if type(sel)==type("string"): sel = AtomSel(sel)

    xSim = getXplorSimulation( sel.simulation() )

    from selectTools import numResidues
    numResidues = numResidues(sel)
    if Rtarget<0:
        Rtarget = (2.2 * numResidues**0.38 -1)
        pass
    
    xSim.command("""
    collapse
    assign (%s) 100.0 %f
    scale %f
    end""" % (sel.string(), Rtarget, scale))
    return

def initCarb13(filenames=[],
               scale=0.5):
    """initialize the XPLOR <l http://nmr.cit.nih.gov/xplor-nih/xplorMan/node384.html
    carbon chemical shift potential term>.

    arguments are:
       filenames   - either a single filename, or a sequence of filenames of
                     chemical shift assignment tables.

    In addition to these files C13SHIFTS:rcoil_c13.tbl and
    C13SHIFTS:expected_edited.tbl are always added.
    """

    xSim = getXplorSimulation()

    if type(filenames)==type("string"): filenames = [filenames]
    restraints=""
    nres=0
    for file in filenames:
        for line in open(file).readlines():
            if line.strip().lower().startswith('assi'): nres += 1
            restraints += line
            pass
        pass

    outputState=xSim.disableOutput()
    xSim.command("""
    carbon
      phistep=180
      psistep=180
      nres=%d
      class all
      force %f
      potential harmonic
      set echo=off mess=off end 
      @C13SHIFTS:rcoil_c13.tbl             !rcoil shifts
      @C13SHIFTS:expected_edited_c13.tbl   !13C shift database
      
      %s
      
      set echo=$prev_echo mess=$prev_messages end 
    end""" % (nres,scale,restraints))
    xSim.enableOutput(outputState)
    return

def initHBDA(filename,
             scale=500,
             simulation=0):
    """initialize the XPLOR hbda potential term
    """
    xSim = getXplorSimulation(simulation)
    lines=open(filename).readlines()
    nres = len(filter(lambda x: x.strip().lower().startswith('assi'),lines))
    outputState=xSim.disableOutput()
    xSim.command("""
    hbda
    nres %d
    class back
    @%s
    force %f
    end
    """ % (nres,filename,scale))
    xSim.enableOutput(outputState)
    return

def initHBDB(selection="not pseudo",
             restraintFile=None,
             prnfrq=0):
    """initialize the XPLOR hbdb potential term
    database hydrogen-bonding term - h-bonds are determined dynamically.

    the selection argument specifies which atoms in included in the
    calculation.

    prnfrq can be changed from zero to periodically print out HBDB info during
    dynamics and minimization.

    By default, HBDB runs in ``free'' mode, in which hydrogen bonds are
    determined on the fly. If you instead wish to use a fixed list of
    h-bonds, specify a filename for the restraintFile argument. 

    The HBDB term may have issues with hetereo multimers. Please use with
    caution.
    
    """

    from selectTools import minResid, maxResid, getSegids, convertToAtomSel
    selection = convertToAtomSel(selection)
    segids = getSegids(selection)

    simulation = selection.simulation()
    xSim = getXplorSimulation(simulation)
    outputState=xSim.disableOutput()
    cmd="""
      hbdb
       kdir = 0.20   !force constant for directional term
       klin = 0.08   !force constant for linear term (ca. Nico's hbda)
       nseg = %d      ! number of segments that hbdb term is active on
       """ % len(segids)
    from atomSel import AtomSel, intersection
    for segid in segids:
        minRes = minResid(intersection(selection,
                                         AtomSel('segid "%4s"' % segid,
                                                 simulation)))
        maxRes = maxResid(intersection(selection,
                                         AtomSel('segid "%4s"' % segid,
                                                 simulation)))
        print 'minResid:',minRes
        print 'maxResid:',maxRes
        print 'segid:',segid
        cmd += '''
        nmin = %d      !range of residues (1st)
        nmax = %d        !range of residues (last)
        segm = "%s"
        ''' % (minRes, maxRes, segid)
        pass
    cmd += """
       ohcut   =  2.60  !cut-off for detection of h-bonds
       coh1cut = 100.0  !cut-off for c-o-h angle in 3-10 helix
       coh2cut = 100.0  !cut-off for c-o-h angle for everything else
       ohncut  = 100.0  !cut-off for o-h-n angle
       updfrq = 10     !update frequency usually 1000
       prnfrq = %d     !print frequency usually 1000
       freemode  = 1     !mode= 1 free search
       fixedmode = 0     !if you want a fixed list, set fixedmode=1, and freemode=0
       mfdir = 0 ! flag that drives HB's to the minimum of the directional potential
       mflin = 0 ! flag that drives HB's to the minimum of the linearity potential
       kmfd = 10.0 ! corresp force const
       kmfl = 10.0 ! corresp force const
       renf = 2.30 ! forces all found HB's below 2.3 A
       kenf = 30.0 ! corresponding force const
       @HBDB:hbdb_files.inp
      end
      """ % prnfrq
    xSim.command(cmd)
    if restraintFile!=None:
        xSim.command(r'''hbdb
                      freemode = 0
                      fixedmode = 1
                      @%s
                     end''' % restraintFile)
        pass
    xSim.enableOutput(outputState)
    return


def initMinimize(ivm,
                 potList=0,
                 printInterval=10,
                 numSteps=500,
                 maxCalls=20000,
                 dEPred=0.001):
    """initialize an IVM object (from the <m ivm> module)
    for Powell minimization.

    In addition to the function arguments, the following IVM parameters are
    initialized:
      constrainLengths
      maxDeltaE
      eTolerance
      gTolerance
    """
    ivm.resetReuse()
#    ivm.setConstrainLengths(0)
    ivm.setMaxDeltaE( 10000 )
    ivm.setStepType("powell")
    ivm.setNumSteps( numSteps )
    ivm.setMaxCalls( maxCalls )
    ivm.setPrintInterval( printInterval )
    ivm.setETolerance(1e-7)
    ivm.setGTolerance(1e-8)
    ivm.setDEpred(dEPred)
    if potList: ivm.setPotList( potList )
    return

def initDynamics(ivm,
                 bathTemp=-1,
                 finalTime=0.2,
                 numSteps=0,
                 stepsize=0.001,
                 potList=0,
                 printInterval=50,
                 initVelocities=0,
                 eTol_factor=0.001,
                 eTol_minimum=0
                 ):
    """
    initialize an IVM object (from the <m ivm> module)
    for PC6 (6th order predictor-corrector) dynamics.
    The default value of bathTemp is the ivm's current value.

    In addition to the function arguments, the following IVM parameters are
    initialized:
      constraintLengths
      maxDeltaE
      responseTime
      eTolerance
      adjustStepsize
      scaleVel
      resetCMInterval

    additionally, if initVelocities!=0, the initial velocities will be
    randomized.

    eTolerance is set by the following formula:
       eTolerance = eTol_factor * bathTemp + eTol_minimum
    """
    from atomAction import randomizeVelocities
    ivm.resetReuse()
    eTol_temp=0
    if bathTemp<0: bathTemp=ivm.bathTemp()
    
    ivm.setBathTemp(bathTemp)
    if initVelocities: randomizeVelocities( bathTemp )
    eTol_temp=eTol_factor*ivm.bathTemp()

#    ivm.setConstrainLengths(0)
    ivm.setMaxDeltaE( 10000 )
    ivm.setStepType("pc6")
    ivm.setResponseTime(5)
    ivm.setStepsize( stepsize ) #initial stepsize value
    ivm.setETolerance( eTol_temp + eTol_minimum)
    ivm.setPrintInterval( printInterval )
    ivm.setAdjustStepsize(1)
    ivm.setScaleVel(1)
    ivm.setResetCMInterval( 10 )
    ivm.setFinalTime(finalTime)
    ivm.setNumSteps(numSteps)
    if potList: ivm.setPotList( potList )
    return

def massSetup(atomicMass=100,
              friction=10):
    """
    set uniform mass and friction values for all atoms.
    Pseudo atoms may have nonuniform masses.
    """
    from atomAction import SetProperty
    AtomSel("all").apply( SetProperty("mass",atomicMass) )
    import varTensorTools, prePotTools, planeDistTools
    varTensorTools.massSetup()
    prePotTools.massSetup()
    planeDistTools.massSetup()
    AtomSel("all").apply( SetProperty("fric",friction) )

def torsionTopology(ivm,fixedOmega=0,oTensors=[]):
    """configure the <m ivm>.IVM topology for standard torsion angle setup:
    group rigid sidechains and break proline, ribose rings in the
    appropriate places. Disulfide bonds are also broken.

    This function sets all groupings and hinge types which are not already
    specified, so it must be called last in the setup of an IVM's topology.

    If fixedOmega is set, also fix protein omega backbone angles.

    oTensors is a list of <m varTensor>.VarTensor objects used for alignment
    tensors
    """
    import varTensorTools, prePotTools, planeDistTools, diffPotTools
    varTensorTools.topologySetup(ivm,oTensors)
    prePotTools.topologySetup(ivm)
    planeDistTools.topologySetup(ivm)
    diffPotTools.topologySetup(ivm)
    
    import selectTools
    if fixedOmega: selectTools.IVM_groupRigidBackbone(ivm)
    selectTools.IVM_groupRigidSidechain(ivm)
    selectTools.IVM_breakProlines(ivm)
    selectTools.IVM_breakRiboses(ivm)
    selectTools.IVM_breakDisulfides(ivm)
    ivm.autoTorsion()
    return

def cartesianTopology(ivm,
                      sel="known",oTensors=[]):
    """configure the <m ivm>.IVM tolopogy for Cartesian dynamics/minimization -
    for the specified selection.

    This consists of breaking topological bonds, and specifying that all atoms
    are tree ``bases.''

    This function should be called after any custom changes are made to the
    ivm's topology setup, but before torsionTopology().

    oTensors is a list of <m varTensor>.VarTensor objects used for alignment
    tensors
    """
                    
    import varTensorTools, prePotTools, planeDistTools, diffPotTools
    varTensorTools.topologySetup(ivm,oTensors)
    prePotTools.topologySetup(ivm)
    planeDistTools.topologySetup(ivm)
    diffPotTools.topologySetup(ivm)

    from atomSel import intersection
    ivm.breakAllBondsIn(intersection(sel,"not pseudo"))
    ivm.setBaseAtoms(sel)
    return


def genExtendedStructure(pdbFilename=0,
                         sel=0,
                         verbose=0,
                         maxFixupIters=500
                         ):
    """
    This assigns X, Y, and Z coordinates to each atom, and then calls
    <m protocol>.fixupCovalentGeom() to correct the covalent geometry, using
    maxFixupIters as the maxIters argument to that function.

    The Y and Z coordinates are random (but small enough (within a range
    of -0.5 to 0.5) to allow bonded atoms to form their bonds) and the X
    coordinate is the atom number divided by 10. This will result in
    an extended configuration along the X axis.

    If pdbFilename is nonnull, the file will be read if it exists, and that
    structure wil be used as a starting point (an attempt will be made to fix
    the the covalent geom).

    Whether it exists or not, it will be written to before returning.
    """

    from atomSel import AtomSel
    if not sel: sel = AtomSel("not pseudo")

    if type(sel)==type('string'): sel = AtomSel(sel)

    xSim = getXplorSimulation(sel.simulation())

    from pdbTool import PDBTool
    import os
    
    if pdbFilename and os.path.exists(pdbFilename):
        PDBTool(pdbFilename,sel).read()
    else:
        from atomSelAction import SetProperty
        import random
        from vec3 import Vec3
        for atom in sel:
            atom.setPos( Vec3(float(atom.index())/10,
                              random.uniform(-0.5,0.5),
                              random.uniform(-0.5,0.5)) )
            pass
        pass
    

    if verbose:
        print "fixing covalent geometry..."
        pass

    fixupCovalentGeom(useVDW=1,maxIters=maxFixupIters,sel=sel,dynRatio=10,
                      verbose=verbose)

    if pdbFilename: PDBTool(pdbFilename,sel).write()

    return
        

    
