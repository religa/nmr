"""generate PSF information from sequence or coordinates.

Particularly useful are the pdbToPSF and seqToPSF routines.
"""

terminalAtoms = ['H5T','H3T']
residueTypes = {}
residueTypes['dna'] = ['CYT', 'GUA', 'ADE', 'THY','C', 'G', 'I', 'INO',
                       'U', 'URA', 'URI']
residueTypes['prot'] = ['ALA', 'ARG', 'ASN', 'ASP', 'CYS', 'CYSP', 'GLN', 'GLU', 'GLY',
                        'HIS', 'ILE', 'LEU', 'LYS', 'MET',
                        'PHE', 'PRO', 'SER', 'THR', 'TRP', 'TYR', 'VAL', 'ACE']


def pdbToSeq(pdbRecord,
             useSeqres=False,
             useChainID=True,
             ):
    """ return a list of list of sequences.
    side effect: set the global variable beginResid

    If useChainID is set, chainID overrides segment name, if it is set.
    """
    ret = []
    seq=[]
    curSeg=0
    curResid=None
    terminate=0
    seg='    '
    resid=None
    lostRes=''  #resid lost if no TER or terminal atoms
    previousTerminate=0 #true if one termination atom has been seen
    beginResid=None
    lines=pdbRecord.split('\n')
    for line in lines:
        if line.startswith('SEQRES') and useSeqres:
            return seqres(lines)
        if line.startswith('TER'): terminate=1
        if line.startswith('ENDMDL'): break
        if line.startswith('ATOM'): 
            res = line[17:21]
            resid = int(line[22:26])
            if beginResid==None: beginResid=resid
            seg = line[72:76]
            seg += ' '*(4-len(seg)) # this for truncated ATOM records
            chainID=line[21]
            if (useChainID or seg=='' or seg=='    ') and chainID!=' ':
                seg = chainID
                pass
            if curSeg==0:
                curSeg=seg
                #print 'curSeg initiated: ', curSeg, chainID, len(seg)
                pass
            atom = line[13:16]
            if seq and seg!=curSeg:
                #print "seq change termination >%s< >%s<" % ( seg, curSeg)
                terminate=1
                lostRes=res
                pass
            #print resid, curResid
            if seq and resid!=curResid and resid!=curResid+1:
                #print "resid skip termination:", resid, curResid
                terminate=1
                lostRes=res
                pass
            if len(seq)>1 and atom in terminalAtoms:
                #print "found terminal atom", len(seq)
                if previousTerminate:
                    terminate=1
                    previousTerminate=0
                    lostRes=res
                else:
                    previousTerminate=1
                    pass
                pass
            if not terminate and resid!=None and resid!=curResid:
                seq.append(res)
                pass
            pass
        if terminate and seq:
            ret.append((beginResid,curSeg,seq))
            previousTerminate=0
            beginResid=None
            seq=[]
            curSeg=0
            if lostRes:
                seq.append(lostRes)
                beginResid=resid
                lostRes=''
                curSeg=seg
                pass
            terminate=0
            curResid=beginResid
        else:
            curResid=resid
            pass
        pass
    if seq: ret.append( (beginResid,curSeg,seq) )
    return ret

def seqres(lines):
    """ read the pdb SEQRES field
    return a list of lists of sequences.

    SEQRES fields include chain specifiers. If this is blank the segid
    is set from the first ATOM entry.
    """
    from simulationWorld  import SimulationWorld_world as simWorld
    if simWorld().logLevel()!='none':
        print "using seqres field"
        pass
    records = filter(lambda x:x.startswith('SEQRES'),lines)

    chains={}
    for record in records:
        record = record[:min(len(record),72)]
        id=record[11]
        residues=record[19:].split()
        if chains.has_key(id):
            chains[id] += residues
        else:
            chains[id] = residues
            pass
        pass
    ids=chains.keys()
    ids.sort()
    ret=[]
    for id in ids:
        ret.append( [1,id,chains[id]] )
        pass

    #get segment names, if chainids are not specified
    if ret[0][1]!=' ':
        return ret

    segs=[]
    chainCnt=0
    prevChainID=''
    for line in lines:
        if line.startswith('ATOM'): 
            seg = line[72:76]
            chainID=line[21]
            if prevChainID and chainID!= prevChainID:
                chainCnt+=1
                pass
            prevChainID=chainID
            resid = int(line[23:26])
            if ret[chainCnt][1]==' ':
                ret[chainCnt][1]=seg
                pass
            if chainCnt+1 >= len(ret):
                break

            if resid>=ret[chainCnt+1][0]:
                chainCnt+=1
                pass
            pass
        pass

    return ret
        

def autoProcessPdbSSBonds(pdbRecord):
    """ scan a PDB file for PDB SSBOND header fields.
    call addDisulfideBond as appropriate

    """
    from simulationWorld  import SimulationWorld_world as simWorld

    lines=pdbRecord.split('\n')
    records = filter(lambda x:x.startswith('SSBOND'),lines)

    if len(records) > 0:
        if simWorld().logLevel()!='none':		   
            print "using ssbond field"
            pass
        pass
    
    for record in records:

        """ These character positions are hard-wired into tbe PDB format """
        
        fromChainName = record[15:17].strip()
        fromResNum = record[18:21]
        toChainName = record[29:31].strip()
        toResNum = record[32:35]

        if len(fromChainName) > 0:
            fromSel = "(segid " + fromChainName + " and resid " + fromResNum + ")"
        else:
            fromSel = "(resid " + fromResNum + ")"
            pass

        if len(toChainName) > 0:
            toSel = "(segid " + toChainName + " and resid " + toResNum + ")"
        else:
            toSel = "(resid " + toResNum + ")"
            pass
                
        addDisulfideBond(fromSel, toSel)
        pass
    return


def deduceSeqType(seq):
    ret='unknown'
    if not seq: return ret
    firstRes=seq[0]
    if len(firstRes)>4:
        raise Exception("invalid residue name: " + firstRes)
    for type in residueTypes.keys():
        if firstRes.strip() in residueTypes[type]: ret=type
        pass
    if ret=='unknown': return ret
    for res in seq:
        if len(res)>4:
            raise Exception("invalid residue name: " + res)
        res = res.strip()
        if not res in residueTypes[ret]:
            raise "residue %s not of type %s in %s" % (res,ret,`seq`)
        pass
    if ret=='dna':
        if 'URI' in seq or 'URA' in seq: ret = 'rna'
    return ret

residueMap={}
residueMap['G'] = 'GUA'
residueMap['C'] = 'CYT'
residueMap['T'] = 'THY'
residueMap['A'] = 'ADE'
residueMap['I'] = 'INO'
    
def renameResidues(seq):
    " single letter to three letter names"
    ret = []
    for r in seq:
        r=r.strip()
        if len(r)==1:
            ret.append( residueMap[r] )
        else:
            ret.append(r)
            pass
        pass
    return ret

def cisPeptide(startResid,
                 segName='    '):
    """
    given a startResid, set up topology to make a cis peptide bond between
    residues numbers startResid and startResid+1.

    Call this routine after seqToPSF.

    This function correctly treats bonds involving proline and non-proline
    residues.

    The optional segName argument argument should be specified if there is
    more than one segment in the structure.
    """
    patch="CISP"
    from atomSel import AtomSel
    if len( AtomSel('resname PRO and resid %d and segid "%s"' % (startResid+1,
                                                                 segName)) ):
        patch="CIPP"
        pass
    from xplorSimulation import getXplorSimulation
    xplor=getXplorSimulation()
    xplor.command('''
    patch %s
    reference=-=( resid %d and segid "%s")
    reference=+=( resid %d and segid "%s") 
    end
    '''% (patch,startResid,segName,startResid+1,segName))

def dAmino(resid,
           segName='    '):
    """
    change given residue to a D-amino acid.

    Call this routine after seqToPSF.

    The optional segName argument argument should be specified if there is
    more than one segment in the structure.
    """
    from xplorSimulation import getXplorSimulation
    xplor=getXplorSimulation()
    xplor.command('''
    patch LtoD 
      reference=nil=( resid %d and segid "%s")
    end''' % (resid,segName))
    return
         

def seqToPSF(seq,
             seqType='auto',
             startResid=1,
             deprotonateHIS=1,
             segName='    ',
             disulfide_bonds=[],
             disulfide_bridges=[],
             amidate_cterm=0,
             customRename=False
             ):
    r"""given a primary protein or nucleic acid sequence, generate PSF info
    and load the appropriate parameters.

    The seq argument can be a string or the name of a file containing the
    sequence.

    if seqType is auto, the type (prot, dna) is determined from the
    sequence. type 'rna' must be explicitly specified.

    If deprotonateHIS is set, the HD1 atom is deleted from Histidines. This is
    the default.

    If segName is shorter than four characters, leading characters are
    space-padded. It is an error for it to be longer than 4 characeters.

    didulfide bonds are specified by a list of resid pairs in either
    disulfide_bonds or disulfide_bridges. Use disulfide_bonds for actual bonds
    and disulfide_bridges to remove the cysteine HG proton- for representing
    disulfide bonds by NOE restraints.

    If customRename is set, certain convenient atom renamings are made for
    nucleic acids:
            ADE H61 --> HN'   
            ADE H62 --> HN''  
            GUA H21 --> HN'   
            GUA H22 --> HN''  
            CYT H41 --> HN'   
            CYT H42 --> HN''  
            THY C5A --> CM    
    """
    from xplorSimulation import getXplorSimulation
    xplor=getXplorSimulation()
    from string import join
    from simulationWorld import SimulationWorld_world as simWorld

    outputState=xplor.disableOutput()

    if len(segName)<4:
        segName="%-4s"%segName
    elif len(segName)>4:
        raise Exception("segName (%s) is too long" % segName)

    import os
    if type(seq)==type("string") and os.path.exists(seq):
        seq = file(seq).read()
        pass
            
    if type(seq)==type("string"):
        seq = seq.split()
        pass

    if seqType=='auto': seqType = deduceSeqType(seq)


    #split up seq to avoid overlong line
    seqs=[[]]
    ind=0
    cnt=0
    for r in seq:
        if cnt>20:
            ind+=1
            seqs.append([])
            cnt=0
            pass
        seqs[ind].append( r )
        cnt+=1
        pass
    splitSeq = join(map(lambda x:join(x),seqs),'\n')
    #seq = join(seq)

    import protocol

    if seqType=='prot':
        protocol.initTopology("protein")#,reset=1)
        protocol.initParams("protein")

        cterm = "CTER"
        if amidate_cterm: cterm = "CTN "
        nterm = r"""
        FIRSt PROP                TAIL + PRO     END { nter for PRO }
        FIRSt NTER                TAIL + *       END
        """
        if seq[0]=='ACE':
            nterm=''
            

        xplor.command('''
        REMARKS  autogenerated by psfGen.py
        segment
        name="%s"
        SETUP=TRUE
        number=%d
        ''' % (segName, startResid) + r'''
        chain
        LINK PEPP    HEAD - *     TAIL + PRO     END  { LINK to PRO }
        LINK PEPT    HEAD - *     TAIL + *       END

        %s
        
        
        LAST  %s   HEAD - *                    END
        

        
        sequence %s
        end
        end
        end
        ''' % (nterm,cterm,splitSeq))

        if deprotonateHIS:
            xplor.command("delete select (name hd1 and resname his) end")
            pass

    elif seqType=='dna':
        protocol.initTopology("nucleic")#,reset=1)
        protocol.initParams("nucleic")

        xplor.command('''
        segment
        name="%s"
        SETUP=TRUE
        number=%d
        ''' % (segName, startResid) + r'''
        chain
        REMARKS  TOPH11.NUC  MACRO for RNA/DNA sequence
        REMARKS  autogenerated by psfGen.py

        ! this is a macro to define standard DNA/RNA polynucleotide bonds
        ! and termini to generate a sequence.
        ! it should be added as @TOPTRNA8.NUC in the SEGMent SEQUence
        ! level.
        ! 
        ! Axel Brunger, 17-AUG-84


        LINK NUC  HEAD - *  TAIL + *  END
        
        FIRST  5ter  TAIL + * END

        LAST 3TER  HEAD - * END
        
        ''' + '''
        sequence %s
        end
        end
        end''' % splitSeq)


        for i in range(startResid,startResid+len(seq)):
            xplor.command('''patch DEOX
                                 reference=NIL=( segid "%4s" and resid %d )
                             end''' % (segName,i))
            pass

        if customRename:
            # rename some atoms
            xplor.command(r'''
            vector do (name "HN'")  ( NAME H61 AND RESNAME ADE )
            vector do (name "HN''")  ( name H62 and resname ADE )
            vector do (name "HN'")  ( name H21 and resname GUA )
            vector do (name "HN''")  ( name H22 and resname GUA )
            vector do (name "HN'")  ( name H41 and resname CYT )
            vector do (name "HN''")  ( name H42 and resname CYT )
            vector do (name "CM")   ( name C5A and resname THY )
            ''')
            pass
        
    elif seqType=='rna':
        protocol.initTopology("nucleic")#,reset=1)
        protocol.initParams("nucleic")

        xplor.command('''
        segment
        name="%s"
        SETUP=TRUE
        number=%d
        ''' % (segName, startResid) + r'''
        chain
        REMARKS  TOPH11.NUC  MACRO for RNA/DNA sequence
        REMARKS  autogenerated by psfGen.py

        ! this is a macro to define standard DNA/RNA polynucleotide bonds
        ! and termini to generate a sequence.
        ! it should be added as @TOPTRNA8.NUC in the SEGMent SEQUence
        ! level.
        ! 
        ! Axel Brunger, 17-AUG-84


        LINK NUC  HEAD - *  TAIL + *  END
        
        FIRST  5ter  TAIL + * END

        LAST 3TER  HEAD - * END
        
        ''' + '''
        sequence %s
        end
        end
        end''' % splitSeq)


        if customRename:
            # rename some atoms
            xplor.command(r'''
            vector do (name "HN'")  ( NAME H61 AND RESNAME ADE )
            vector do (name "HN''")  ( name H62 and resname ADE )
            vector do (name "HN'")  ( name H21 and resname GUA )
            vector do (name "HN''")  ( name H22 and resname GUA )
            vector do (name "HN'")  ( name H41 and resname CYT )
            vector do (name "HN''")  ( name H42 and resname CYT )
            vector do (name "CM")   ( name C5A and resname THY )
            ''')
            pass
        


    else:
        from simulationWorld  import SimulationWorld_world as simWorld
        if simWorld().logLevel()!='none':
            print "seqToPSF: Warning: ",\
                  "unsupported sequence type: %s:" % seqType, splitSeq
        pass

    for (res1,res2) in disulfide_bonds:
        xplor.command('''
        patch DISU 
          reference=1=( segid "%4s" and resid %d )  
          reference=2=( segid "%4s" and resid %d )  
        end''' % (segName,res1,segName,res2))
	pass
    
    for (res1,res2) in disulfide_bridges:
	xplor.command('''
        patch DISN
          reference=1=( segid "%4s" and resid %d )  
          reference=2=( segid "%4s" and resid %d )  
        end''' % (segName,res1,segName,res2))

    xplor.enableOutput(outputState)
        
    return

def renameAtoms(sel='all'):
    from atomSel import AtomSel
    if type(sel)==type('string'): sel = AtomSel(sel)

    for atom in sel:
        name=atom.atomName()

        if name.find("*")>=0: name = name.replace("*","'")

        atom.setAtomName(name)
        pass
    return


def pdbToPSF(pdbRecord,psfFilename='',
             customRename=False):
    """given a PDB record, generate XPLOR PSF structure/topology info.

    The PDB record can be a filename or a string containing PDB contents.

    See seqToPSF for documentation on customRename.
    """
    from xplorSimulation import getXplorSimulation
    xplor=getXplorSimulation()

    try:
        import os
        os.stat(pdbRecord)
        pdbRecord = open(pdbRecord).read()
    except:
        pass

    outputState=xplor.disableOutput()
    sequences = pdbToSeq(pdbRecord)

    for (beginResid, segid, seq) in sequences:
        seq = renameResidues(seq)
        if segid=='*': segid=''
        #print type, beginResid, segid, seq
        seqToPSF(seq,seqType='prot',startResid=beginResid,segName=segid,
                 deprotonateHIS=False,customRename=customRename)
        pass

    autoProcessPdbSSBonds(pdbRecord)
    
    if psfFilename:
        xplor.command("write psf output=%s end" % psfFilename)

    #renameAtoms()
    xplor.enableOutput(outputState)
    return

def addDisulfideBond(sel1,sel2):
    """ add a disulfide bond between residues in the two atom selections

    Should be called after PSF information is generated.
    """

    from atomSel import AtomSel
    if isinstance(sel1,str): sel1 = AtomSel(sel1)
    if isinstance(sel2,str): sel2 = AtomSel(sel2)

    if sel1.simulation().name() != sel2.simulation().name():
        raise Exception("no disulfide bond between different Simulations!")

    from xplorSimulation import getXplorSimulation    
    xSim = getXplorSimulation(sel1.simulation())

    if len(AtomSel('segid "%s" and resid %d and name SG'%
                   (sel1[0].segmentName(),sel1[0].residueNum())))==0:
        raise Exception("No sulfur atom in "+sel1.string())
    if len(AtomSel('segid "%s" and resid %d and name SG'%
                   (sel2[0].segmentName(),sel2[0].residueNum())))==0:
        raise Exception("No sulfur atom in "+sel2.string())
    
    xSim.command("""patch
                       DISU reference=1=( segid "%s" and resid %d )
                            reference=2=( segid "%s" and resid %d )
                     end""" % (sel1[0].segmentName(),sel1[0].residueNum(),
                               sel2[0].segmentName(),sel2[0].residueNum()))
    return

