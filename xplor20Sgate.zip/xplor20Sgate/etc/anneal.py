
xplor.requireVersion("2.14.4")

from sys import path
path.insert(0, "python/")

# filename for output structures. This string must contain the STRUCTURE
# literal so that each calculated structure has a unique name. The SCRIPT
# literal is replaced by this filename (or stdin if redirected using <),
# but it is optional.
#

#inChain is decided at random
#inChain=3		# Number of chains which are 'in' (i.e. state B/C)
#inList="" 		# This will be updated during the calculation of the individual structures.

runId = -1		# This is the ID of the run, if ran from condor (usually the same as directory name, condor job ID)
outFilename = "results/anneal/anneal_STRUCTURE.pdb"
numberOfStructures=1   #usually you want to create at least 20 

# protocol module has many high-level helper functions.
#
import protocol
from os import getpid
protocol.initRandomSeed(getpid())
protocol.initTopology(('protein', 'toppar/TEMPO.top'))
protocol.initParams(('protein','toppar/TEMPO.par'))

command = xplor.command
xc=xplor.command

# generate PSF data from sequence and initialize the correct parameters.
#
from psfGen import seqToPSF
protocol.initStruct("input/min.spinlabel.psf")

# Load initial structure with correct covalent geometry
#
protocol.initCoords("input/min.spinlabel.pdb", verbose=1)

from atomSel import AtomSel

nterm = AtomSel("resi 97:106")
nterm_all = AtomSel("resi 97:113")
alpha = AtomSel("resi 114:333 and segid A:G")
alpha_sl = AtomSel("(resi 114:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N or name HA or name CB))")
alpha_allsl = AtomSel("(resi 114:333 and segid A:G) or (segid 1:7)")


def constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1, vdw2=10):
    xc("""constraints 
 fix (resi 114:333 and segid A:G) 
 fix (segid 1:7 and (name CA or name C or name N or name HA or name CB))
end 
constraints 

! Spin label should steer clear of the alpha subunit
 interaction (segid 1:7) 
 ((resi 97:118 or resi 122:170 or resi 174:193 or resi 197:205 or resi 209:213 or resi 217:241 or resi 245:333) 
 and (name CA or name C or name N or name HA or name HA* or name HN or name O or name CB or name HB*)
 and segid A:G) weights vdw 10 end 

!
! and (name CA or name C or name N or name HA or name HA* or name HN or name O or name CB or name HB*)
! Spin label should maintain all its bond / angles and impropers
 interaction (segid 1:7 and resi 120) (segid 1:7 and resi 120)  weights * 1 end 
 interaction (segid 1:7 and resi 172) (segid 1:7 and resi 172)  weights * 1 end 
 interaction (segid 1:7 and resi 195) (segid 1:7 and resi 195)  weights * 1 end 
 interaction (segid 1:7 and resi 207) (segid 1:7 and resi 207)  weights * 1 end 
 interaction (segid 1:7 and resi 215) (segid 1:7 and resi 215)  weights * 1 end 
 interaction (segid 1:7 and resi 243) (segid 1:7 and resi 243)  weights * 1 end 

! Ntermini shouldn't bump into each other
 interaction (resi 97:114) (resi 97:114) weights bond %.2f angle %.2f impr %.2f vdw %.2f end 
! Or into the alpha subunit
 interaction (resi 97:113) (resi 114:333) weights vdw %.2f end 

end"""%(bond,angle,impr,vdw, vdw2))
    # print "noe.scale =", noe.scale()
    pass

def writeStruct(name="out.pdb"):
    xc("write coor output = %s end"%(name))
    pass

# a PotList contains a list of potential terms. This is used to specify which
# terms are active during refinement.
#
from potList import PotList
potList = PotList()

# parameters to ramp up during the simulated annealing protocol
#
from simulationTools import MultRamp, StaticRamp, InitialParams,analyze

rampedParams=[]
highTempParams=[]

# compare atomic Cartesian rmsd with a reference structure
#  backbone and heavy atom RMSDs will be printed in the output
#  structure files
#
#from posDiffPotTools import create_PosDiffPot
#refRMSD = create_PosDiffPot("refRMSD","resi 13:233 and name CA or name C or name N",
#                            pdbFile='input/start.pdb',
#                            cmpSel="not name H*")

# set up NOE potential (i.e. PRE potential)
noe=PotList('noe')

inListAll=[[""], ["A"], ["AB", "AC", "AD"], ["ABC", "ABD", "ABE", "ABF", "ACE"], ["ABCD", "ABCE", "ABCF", "ABDE", "ABDF"], ["ABCDE", "ABCDF", "ABCEF"], ["ABCDEF"], ["ABCDEFG"]]
import operator
inListAllFlat=reduce(operator.add, inListAll)


potList.append(noe)
from noePotTools import create_NOEPot
from random import randint
from noePotTools import create_NOEPot
files = ["input/methyl/M40.tbl"]
if runId<0:
    inChain=randint(0,4)
    print "inChain =", inChain
    r = randint(0,len(inListAll[inChain])-1)
    inList=inListAll[inChain][r]
    print "r =", r, "inList =", inList
else:
    inList=inListAllFlat[runId%15]	#  mod(runId,15) ensures that all the states are sampled equally
    inChain=len(inList)			
    print "inList =", inList

outList=""
for chain in "ABCDEFG":
    if chain in inList:
        # Add the potential for the 'in' guy 
        files.append("input/methyl/IN.%s.tbl"%(chain))
    else:
        # Add the potential for the 'out' guy
        files.append("input/methyl/OUT.%s.tbl"%(chain))
        outList=outList+chain

# Now discard the old NOE potential and generate the new NOE one:
pot = create_NOEPot('metsep', files)
pot.setScale(1)
noe.append(pot)

# Create also the combined NOE file
pot = create_NOEPot('metcomb', ["input/methyl/M40.tbl", "input/methyl/IN.%s.tbl"%inList, "input/methyl/OUT.%s.tbl"%outList])
pot.setScale(0)
noe.append(pot)


if inChain==3:
    pot = create_NOEPot('amide', "input/amide.tbl")
    pot.setScale(1)
    noe.append(pot)

rampedParams.append( MultRamp(2,300, "noe.setScale( VALUE )") )

from xplorPot import XplorPot

#Rama torsion angle database
#
protocol.initRamaDatabase()
potList.append( XplorPot('RAMA') )
rampedParams.append( MultRamp(.002,1,"potList['RAMA'].setScale(VALUE)") )

#
# setup parameters for atom-atom repulsive term. (van der Waals-like term)
#
potList.append( XplorPot('VDW') )
rampedParams.append( StaticRamp("protocol.initNBond(tolerance=1.0)") )
rampedParams.append( MultRamp(1.2,0.8,
                              "command('param nbonds repel VALUE end end')") )
rampedParams.append( MultRamp(0.1,4,
                              "command('param nbonds rcon VALUE end end')") )
highTempParams.append( StaticRamp("""protocol.initNBond(cutnb=10,
                                                        rcon=0.1,
                                                        tolerance=3.0,
                                                        repel=1.2)""") )


potList.append( XplorPot("BOND") )
potList.append( XplorPot("ANGL") )
potList['ANGL'].setThreshold( 5 )
rampedParams.append( MultRamp(0.4,1,"potList['ANGL'].setScale(VALUE)") )
potList.append( XplorPot("IMPR") )
potList['IMPR'].setThreshold( 5 )
rampedParams.append( MultRamp(0.1,1,"potList['IMPR'].setScale(VALUE)") )
      


# Give atoms uniform weights, except for the anisotropy axis
#
protocol.massSetup()


# IVM setup
#   the IVM is used for performing dynamics and minimization in torsion-angle
#   space, and in Cartesian space.
#


from ivm import IVM
dyn = IVM()

# This is to fix the big alpha subunit
dyn.fix(alpha_allsl)
dyn.group(alpha_allsl)
dyn.setBaseAtoms("not resname ANI")

# initialize ivm topology for torsion-angle dynamics
protocol.torsionTopology(dyn)

# minc used for final cartesian minimization
#
minc = IVM()
protocol.initMinimize(minc)

protocol.cartesianTopology(minc)
minc.fix(alpha_sl)
minc.group(alpha_sl)
#minc.setStepsize(1e-4)
minc.setBaseAtoms("not resname ANI")



# object which performs simulated annealing
#
from simulationTools import AnnealIVM
init_t  = 3500.     # Need high temp and slow annealing to converge
cool = AnnealIVM(initTemp =init_t,
                 finalTemp=25,
                 tempStep =200, # Was 12.5 (Tomek)
                 ivm=dyn,
                 extraCommands="constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)",
                 rampedParams = rampedParams)

#cart_cool is for optional cartesian-space cooling
cart_cool = AnnealIVM(initTemp =650,
	              finalTemp=25,
		      tempStep =100,
                      ivm=minc,
                      extraCommands="constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)")
#,
#                      rampedParams = rampedParams)

def calcOneStructure(loopInfo):
    """ this function calculates a single structure, performs analysis on the
    structure, and then writes out a pdb file, with remarks.
    """
    dyn.fix(alpha_allsl)
    dyn.group(alpha_allsl)
    dyn.setBaseAtoms("not resname ANI")
    protocol.torsionTopology(dyn)

    # Change the NOE potential list
    potList['noe']['metcomb'].setScale(0)
    potList['noe']['metsep'].setScale(1)

    # generate a new structure with randomized torsion angles
    # for nterm (i.e. -3 to 6)
    constrainAlpha(bond=1, angle=1, impr=1, vdw=1, vdw2=10)
    from monteCarlo import randomizeTorsions
    randomizeTorsions(dyn, sel=nterm)

    #writeStruct("results/mc.pdb")
    
    # initialize parameters for high temp dynamics.
    InitialParams( rampedParams )
    # high-temp dynamics setup - only need to specify parameters which
    #   differfrom initial values in rampedParams
    InitialParams( highTempParams )

    # high temp dynamics with NOEs off (i.e. very weak NOEs)
    #
    protocol.initDynamics(dyn,
                      potList=potList, # potential terms to use
                      bathTemp=init_t,
                      initVelocities=1,
                      finalTime=20,   # stops at 800ps or 8000 steps
                      numSteps=2000,   # whichever comes first
                      printInterval=100)

    constrainAlpha(bond=1.0, angle=0.1, impr=0.1, vdw=0.0, vdw2=10)

    dyn.setETolerance( init_t/100 )  #used to det. stepsize. default: t/1000 
    noe.setScale(0.2)
    #simWorld.setLogLevel("debug")
    #dyn.setVerbose(0xffff)
    dyn.run()
    #writeStruct("results/ht1.pdb")

    # high temp dynamics with NOEs ON
    #
    protocol.initDynamics(dyn,
                          potList=potList, # potential terms to use
                          bathTemp=init_t,
                          initVelocities=1,
                          finalTime=30,   # stops at 800ps or 8000 steps
                          numSteps=3000,   # whichever comes first
                          printInterval=100)

    constrainAlpha(bond=1.0, angle=0.1, impr=0.1, vdw=0.0, vdw2=10)

    dyn.setETolerance( init_t/100 )  #used to det. stepsize. default: t/1000 
    noe.setScale(2.0)

    dyn.run()
    #writeStruct("results/ht2.pdb")

    
    # high temp dynamics with NOEs ON
    #
    protocol.initDynamics(dyn,
                          potList=potList, # potential terms to use
                          bathTemp=init_t,
                          initVelocities=1,
                          finalTime=10,   # stops at 800ps or 8000 steps
                          numSteps=1000,   # whichever comes first
                          printInterval=100)

    constrainAlpha(bond=1.0, angle=0.1, impr=0.1, vdw=0.1, vdw2=10)

    dyn.setETolerance( init_t/100 )  #used to det. stepsize. default: t/1000 
    noe.setScale(2.0)

    dyn.run()
    #writeStruct("results/ht3.pdb")

    # initialize parameters for cooling loop
    InitialParams( rampedParams )


    # initialize integrator for simulated annealing
    #

    dyn.reset()
    dyn.fix(alpha_sl)
    dyn.group(alpha_sl)
    dyn.setBaseAtoms("not resname ANI") 
    protocol.torsionTopology(dyn)
    protocol.initDynamics(dyn,
                          potList=potList,
                          numSteps=2000,       #at each temp: 200 steps or
                          finalTime=2.0 ,       # .2ps, whichever is less
                          printInterval=100)

    # perform simulated annealing
    #
    constrainAlpha(bond=1.0, angle=1, impr=1, vdw=1.0, vdw2=10)
    cool.run()
    #writeStruct("results/cool.pdb")
            
    # final torsion angle minimization
    #
    protocol.initMinimize(dyn,
                          numSteps=500,
                          potList=potList,
                          printInterval=10)
    
    constrainAlpha(bond=1.0, angle=1, impr=1, vdw=1.0, vdw2=10)

    dyn.run()
    #writeStruct("results/min1.pdb")
   
    # optional cooling in Cartesian coordinates
    #
    # Change the NOE potential list
    potList['noe']['metsep'].setScale(0)
    potList['noe']['metcomb'].setScale(1)

    protocol.initDynamics(minc,
                          potList=potList,
                          numSteps=2000,
                          finalTime=1.0,
                          printInterval=100)

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    cart_cool.run()

    #writeStruct("results/cartcool.pdb")

    # final all- atom minimization
    #
    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    protocol.initMinimize(minc,
                          numSteps=500, 
                          potList=potList,
                          dEPred=10,
                          printInterval=1)

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    minc.run()

    #do analysis and write structure
    loopInfo.writeStructure(potList)
    pass



from simulationTools import StructureLoop, FinalParams
StructureLoop(numStructures=numberOfStructures,
              pdbTemplate=outFilename,
              structLoopAction=calcOneStructure,
              genViolationStats=0,
              averageFilename=None,
              inChain=inChain,
              inList=inList).run()


