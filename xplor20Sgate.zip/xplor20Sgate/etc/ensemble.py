
xplor.requireVersion("2.14.4")

import trace
from sys import path,exit
path.insert(0, "python/")

inList="ABC"		# This will be updated during the calculation of the individual structures.
inChain=len(inList)	# Number of chains which are 'in' (i.e. state B/C)

inFilename = "tmp/anneal.pdb"
outFilename = "results/anneal/anneal_STRUCTURE_MEMBER.pdb"
numberOfStructures=25   # usually you want to create at least 20 
ensembleSize=2  	# how many structures to average over


import protocol
from os import getpid
protocol.initRandomSeed(getpid())
protocol.initTopology(('protein', 'toppar/TEMPO.top'))
protocol.initParams(('protein','toppar/TEMPO.par'))

command = xplor.command
xc=xplor.command

# generate PSF data from sequence and initialize the correct parameters.
#
from psfGen import seqToPSF
protocol.initStruct("input/min.spinlabel.psf")

# Load initial structure with correct covalent geometry
#
protocol.initCoords(inFilename, verbose=1)


# Get all the standard functions which we wrote to calculate the structure
# of N-termini
#
from proteasome import *


# Setup stuff required for ensemble simulation
#
from ensembleSimulation import EnsembleSimulation
esim = EnsembleSimulation("ensemble", ensembleSize)


# a PotList contains a list of potential terms. This is used to specify which
# terms are active during refinement.
#
from potList import PotList
potList = PotList()

# parameters to ramp up during the simulated annealing protocol
#
from simulationTools import MultRamp, StaticRamp, InitialParams,analyze
from avePot import AvePot

rampedParams=[]
highTempParams=[]

# set up NOE potential (i.e. PRE potential)
noe=PotList('noe')

potList.append(noe)
from noePotTools import create_NOEPot
from random import randint
from noePotTools import create_NOEPot
files = ["input/methyl/M40.tbl"]
# Here inList is defined on the top by appropriately perl-substituting 
print "inList =", inList
for chain in "ABCDEFG":
    if chain in inList:
        # Add the potential for the 'in' guy 
        files.append("input/methyl/IN.%s.tbl"%(chain))
    else:
        # Add the potential for the 'out' guy
        files.append("input/methyl/OUT.%s.tbl"%(chain))
# Now discard the old NOE potential and generate the new NOE one:
pot = create_NOEPot('methyl', files)
pot.setScale(1)
noe.append(pot)


if inChain==3:
    pot = create_NOEPot('amide', "input/amide.tbl")
    pot.setScale(1)
    noe.append(pot)


rampedParams.append( MultRamp(2,300, "noe.setScale( VALUE ); command('noe scale all VALUE end')") )

from xplorPot import XplorPot

#Rama torsion angle database
#
protocol.initRamaDatabase()
potList.append( AvePot(XplorPot, 'RAMA') )
rampedParams.append( MultRamp(.002,1,"potList['RAMA'].setScale(VALUE)") )


# setup parameters for atom-atom repulsive term. (van der Waals-like term)
#
potList.append( AvePot(XplorPot, "VDW") )
rampedParams.append( StaticRamp("protocol.initNBond(tolerance=1.0)") )
rampedParams.append( MultRamp(1.2,0.8,
                              "command('param nbonds repel VALUE end end')") )
rampedParams.append( MultRamp(0.1,4,
                              "command('param nbonds rcon VALUE end end')") )
highTempParams.append( StaticRamp("""protocol.initNBond(cutnb=10,
                                                        rcon=0.1,
                                                        tolerance=3.0,
                                                        repel=1.2)""") )
potList.append( AvePot(XplorPot, "BOND") )
potList.append( AvePot(XplorPot, "ANGL") )
potList['ANGL'].setThreshold( 5 )
rampedParams.append( MultRamp(0.4,1,"potList['ANGL'].setScale(VALUE)") )
potList.append( AvePot(XplorPot, "IMPR") )
potList['IMPR'].setThreshold( 5 )
rampedParams.append( MultRamp(0.1,1,"potList['IMPR'].setScale(VALUE)") )

# Give atoms uniform weights, except for the anisotropy axis
#
protocol.massSetup()

# IVM setup
#   the IVM is used for performing dynamics and minimization in torsion-angle
#   space, and in Cartesian space.
#
from ivm import IVM
dyn = IVM(esim)
#dyn = IVM()

# This is to fix the big alpha subunit
dyn.fix(alpha_sl)
dyn.group(alpha_sl)
dyn.setBaseAtoms("not resname ANI")

# initialize ivm topology for torsion-angle dynamics
protocol.torsionTopology(dyn)

# minc used for final cartesian minimization
#
minc = IVM(esim)
#minc = IVM()
protocol.initMinimize(minc)

protocol.cartesianTopology(minc)
minc.fix(alpha_sl)
minc.group(alpha_sl)
minc.setBaseAtoms("not resname ANI")

# object which performs simulated annealing
#
from simulationTools import AnnealIVM
init_t  = 3500.     # Need high temp and slow annealing to converge
cool = AnnealIVM(initTemp =init_t,
                 finalTemp=25,
                 tempStep =200, # Was 12.5 (Tomek)
                 ivm=dyn,
                 extraCommands="constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)",
                 rampedParams = rampedParams)

cart_cool = AnnealIVM(initTemp =650,
                      finalTemp=25,
                      tempStep =200,
                      ivm=minc,
                      extraCommands="constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)")
#,
#                      rampedParams = rampedParams)



def calcOneStructure(loopInfo):
    """ this function calculates a single structure, performs analysis on the
    structure, and then writes out a pdb file, with remarks.
    """
    # initialize parameters for high temp dynamics.
    InitialParams( rampedParams )
    # high-temp dynamics setup - only need to specify parameters which
    #   differfrom initial values in rampedParams
    InitialParams( highTempParams )

    # high temp dynamics
    #
    protocol.initDynamics(dyn,
                      potList=potList, # potential terms to use
                      bathTemp=init_t,
                      initVelocities=1,
                      finalTime=100,   # stops at 800ps or 8000 steps
                      numSteps=1000,   # whichever comes first
                      printInterval=100)

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)

    dyn.setETolerance( init_t/100 )  #used to det. stepsize. default: t/1000 
    dyn.run()

    protocol.initDynamics(dyn,
                          potList=potList,
                          numSteps=1000,       #at each temp: 1000 steps or
                          finalTime=1.0 ,       # 1.0ps, whichever is less
                          printInterval=100)
    # perform simulated annealing
    #

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    cool.run()
            
    # final torsion angle minimization
    #
    protocol.initMinimize(dyn,
                          printInterval=50)

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    dyn.run()

    # optional cooling in Cartesian coordinates
    #
    protocol.initDynamics(minc,
                          potList=potList,
                          numSteps=1000,       #at each temp: 100 steps or
                          finalTime=.5 ,       # .2ps, whichever is less
                          printInterval=100)

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    cart_cool.run()

    # final all- atom minimization
    #
    protocol.initMinimize(minc,
                          potList=potList,
                          dEPred=10)

    constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1.0, vdw2=10)
    minc.run()

    #do analysis and write structure
    loopInfo.writeStructure(potList)
    pass


from simulationTools import StructureLoop, FinalParams
StructureLoop(numStructures=numberOfStructures,
              pdbTemplate=outFilename,
              structLoopAction=calcOneStructure,
              genViolationStats=0,
              averageContext=FinalParams(rampedParams),
              averageFilename=None,
              inChain=inChain,
              inList=inList).run()



