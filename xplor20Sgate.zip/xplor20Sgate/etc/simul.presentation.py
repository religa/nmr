
xplor.requireVersion("2.14.4")

from sys import path
path.insert(0, "python/")

# filename for output structures. This string must contain the STRUCTURE
# literal so that each calculated structure has a unique name. The SCRIPT
# literal is replaced by this filename (or stdin if redirected using <),
# but it is optional.
#

#inChain is decided at random
#inChain=3		# Number of chains which are 'in' (i.e. state B/C)
#inList="" 		# This will be updated during the calculation of the individual structures.

runId = -1		# This is the ID of the run, if ran from condor (usually the same as directory name, condor job ID)
inFilename = "results/in.pdb"
outFilename = "results/anneal/out.pdb"
numberOfStructures=1   #usually you want to create at least 20 

# protocol module has many high-level helper functions.
#
import protocol
from os import getpid
protocol.initRandomSeed(getpid())
protocol.initTopology(('protein', 'toppar/TEMPO.top'))
protocol.initParams(('protein','toppar/TEMPO.par'))

command = xplor.command
xc=xplor.command

# generate PSF data from sequence and initialize the correct parameters.
#
from psfGen import seqToPSF
protocol.initStruct("input/min.spinlabel.psf")

# Load initial structure with correct covalent geometry
#
protocol.initCoords(inFilename, verbose=1)

from atomSel import AtomSel

nterm = AtomSel("resi 97:106")
nterm_all = AtomSel("resi 97:113")
alpha = AtomSel("resi 114:333 and segid A:G")
alpha_sl = AtomSel("(resi 114:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N or name HA or name CB))")
alpha_allsl = AtomSel("(resi 114:333 and segid A:G) or (segid 1:7)")


def constrainAlpha(bond=1.0, angle=1.0, impr=1.0, vdw=1, vdw2=10):
    xc("""constraints 
 fix (resi 114:333 and segid A:G) 
 fix (segid 1:7 and (name CA or name C or name N or name HA or name CB))
end 
constraints 

! Spin label should steer clear of the alpha subunit
 interaction (segid 1:7) 
 ((resi 97:118 or resi 122:170 or resi 174:193 or resi 197:205 or resi 209:213 or resi 217:241 or resi 245:333) 
 and (name CA or name C or name N or name HA or name HA* or name HN or name O or name CB or name HB*)
 and segid A:G) weights vdw 10 end 

!
! and (name CA or name C or name N or name HA or name HA* or name HN or name O or name CB or name HB*)
! Spin label should maintain all its bond / angles and impropers
 interaction (segid 1:7 and resi 120) (segid 1:7 and resi 120)  weights * 1 end 
 interaction (segid 1:7 and resi 172) (segid 1:7 and resi 172)  weights * 1 end 
 interaction (segid 1:7 and resi 195) (segid 1:7 and resi 195)  weights * 1 end 
 interaction (segid 1:7 and resi 207) (segid 1:7 and resi 207)  weights * 1 end 
 interaction (segid 1:7 and resi 215) (segid 1:7 and resi 215)  weights * 1 end 
 interaction (segid 1:7 and resi 243) (segid 1:7 and resi 243)  weights * 1 end 

! Ntermini shouldn't bump into each other
 interaction (resi 97:114) (resi 97:114) weights bond %.2f angle %.2f impr %.2f vdw %.2f end 
! Or into the alpha subunit
 interaction (resi 97:113) (resi 114:333) weights vdw %.2f end 

end"""%(bond,angle,impr,vdw, vdw2))
    pass

def writeStruct(name="out.pdb"):
    xc("write coor output = %s end"%(name))
    pass

# a PotList contains a list of potential terms. This is used to specify which
# terms are active during refinement.
#
from potList import PotList
potList = PotList()

# parameters to ramp up during the simulated annealing protocol
#
from simulationTools import MultRamp, StaticRamp, InitialParams,analyze

rampedParams=[]
highTempParams=[]

# compare atomic Cartesian rmsd with a reference structure
#  backbone and heavy atom RMSDs will be printed in the output
#  structure files
#
#from posDiffPotTools import create_PosDiffPot
#refRMSD = create_PosDiffPot("refRMSD","resi 13:233 and name CA or name C or name N",
#                            pdbFile='input/start.pdb',
#                            cmpSel="not name H*")

# set up NOE potential (i.e. PRE potential)

inListAll=[[""], ["A"], ["AB", "AC", "AD"], ["ABC", "ABD", "ABE", "ABF", "ACE"], ["ABCD", "ABCE", "ABCF", "ABDE", "ABDF"], ["ABCDE", "ABCDF", "ABCEF"], ["ABCDEF"], ["ABCDEFG"]]
import operator
inListAllFlat=reduce(operator.add, inListAll)


from xplorPot import XplorPot

#Rama torsion angle database
#
protocol.initRamaDatabase()
potList.append( XplorPot('RAMA') )
rampedParams.append( MultRamp(.002,1,"potList['RAMA'].setScale(VALUE)") )

#
# setup parameters for atom-atom repulsive term. (van der Waals-like term)
#
potList.append( XplorPot('VDW') )
rampedParams.append( StaticRamp("protocol.initNBond(tolerance=1.0)") )
rampedParams.append( MultRamp(1.2,0.8,
                              "command('param nbonds repel VALUE end end')") )
rampedParams.append( MultRamp(0.1,4,
                              "command('param nbonds rcon VALUE end end')") )
highTempParams.append( StaticRamp("""protocol.initNBond(cutnb=10,
                                                        rcon=0.1,
                                                        tolerance=3.0,
                                                        repel=1.2)""") )


potList.append( XplorPot("BOND") )
potList.append( XplorPot("ANGL") )
potList['ANGL'].setThreshold( 5 )
rampedParams.append( MultRamp(0.4,1,"potList['ANGL'].setScale(VALUE)") )
potList.append( XplorPot("IMPR") )
potList['IMPR'].setThreshold( 5 )
rampedParams.append( MultRamp(0.1,1,"potList['IMPR'].setScale(VALUE)") )
      


# Give atoms uniform weights, except for the anisotropy axis
#
protocol.massSetup()


# IVM setup
#   the IVM is used for performing dynamics and minimization in torsion-angle
#   space, and in Cartesian space.
#


from ivm import IVM
dyn = IVM()

# This is to fix the big alpha subunit
dyn.fix(alpha_allsl)
dyn.group(alpha_allsl)
dyn.setBaseAtoms("not resname ANI")

# initialize ivm topology for torsion-angle dynamics
protocol.torsionTopology(dyn)

dyn.fix(alpha_allsl)
dyn.group(alpha_allsl)
dyn.setBaseAtoms("not resname ANI")
protocol.torsionTopology(dyn)


constrainAlpha(bond=1, angle=1, impr=1, vdw=1, vdw2=10)

#writeStruct("results/mc.pdb")

# initialize parameters for high temp dynamics.
InitialParams( rampedParams )
# high-temp dynamics setup - only need to specify parameters which
#   differfrom initial values in rampedParams
InitialParams( highTempParams )

# high temp dynamics with NOEs off (i.e. very weak NOEs)
#
init_t=3500
protocol.initDynamics(dyn,
                  potList=potList, # potential terms to use
                  bathTemp=init_t,
                  initVelocities=1,
                  finalTime=20,   # stops at 800ps or 8000 steps
                  numSteps=100,   # whichever comes first
                  printInterval=100)

constrainAlpha(bond=1.0, angle=1, impr=1, vdw=1.0, vdw2=10)

dyn.setETolerance( init_t/100 )  #used to det. stepsize. default: t/1000 

#dyn.setVerbose(0xffff)
for i in range(1000):
    dyn.run()
    writeStruct("results/out_%s.pdb"%i)


writeStruct("results/ht1.pdb")



