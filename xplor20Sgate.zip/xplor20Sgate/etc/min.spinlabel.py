# Minimise that piece of shit:

import sys
sys.path.insert(0, "python/")
from glob import  glob
import protocol
xc=xplor.command
protocol.initRandomSeed()   #set random seed - by time
protocol.initTopology(('protein', 'toppar/TEMPO.top'))
protocol.initParams(('protein', 'toppar/TEMPO.par'))

from psfGen import *

psf_list = ["input/min.psf"]
psf_list.extend(glob("tmp/TEMPO/TEMPO.*.psf"))
psf_list.extend(glob("tmp/MTSL/CYSP.*.psf"))

protocol.initStruct(psf_list)

pdb_list = ["input/min.pdb"]
pdb_list.extend(glob("tmp/TEMPO/mob.*.*.pdb"))
pdb_list.extend(glob("tmp/MTSL/mob.*.*.pdb"))

protocol.initCoords(pdb_list, verbose=1)
xc('vector show element (resid) (not known)')

# This patches the A-2 residue with a TEMPO spin label
#for seg in ['A', 'B', 'C', 'D', 'E', 'F', 'G']:
#    xc('patch TEMA reference=1=(resid -2 and segid %s and resn ALA) reference=2=(resid -2 and segid %s and resn TES) end'%(seg,seg))

# This patches the G104 residue with a TEMPO spin label
for seg in ['A', 'B', 'C', 'D', 'E', 'F', 'G']:
    xc('patch TEMG reference=1=(resid 104 and segid %s and resn GLY) reference=2=(resid 104 and segid %s and resn TES) end'%(seg,seg))



xc("write coor output= tmp/start.spinlabel.pdb end")
xc("write psf output= tmp/start.spinlabel.psf end")



from potList import PotList
potList = PotList()
from xplorPot import XplorPot
from simulationTools import MultRamp, StaticRamp, InitialParams,analyze

from xplorPot import XplorPot
protocol.initDihedrals("input/dihedral.tbl", useDefaults=0)

potList.append( XplorPot('CDIH'))
potList.append( XplorPot('VDW') )
potList.append( XplorPot("BOND") )
potList.append( XplorPot("ANGL") )
potList.append( XplorPot("IMPR") )

rampedParams=[]
#rampedParams.append( StaticRamp("potList['CDIH'].setScale(200)") )
rampedParams.append( MultRamp(20, 200, "potList['CDIH'].setScale(VALUE)") )
rampedParams.append( StaticRamp("protocol.initNBond()") )
rampedParams.append( MultRamp(1.2,0.85,
                              "xc('param nbonds repel VALUE end end')") )
rampedParams.append( MultRamp(.004,4,
                              "xc('param nbonds rcon VALUE end end')") )
rampedParams.append( MultRamp(0.4,1,"potList['ANGL'].setScale(VALUE)") )
rampedParams.append( MultRamp(0.1,1,"potList['IMPR'].setScale(VALUE)") )


protocol.massSetup()



def constrainAlpha(vdw_mtsl=1, vdw_nterm=1):
    xc("""constraints 
 fix (resi 107:333 and segid A:G) 
 fix (segid 1:7 and (name CA or name C or name N))  
end 
constraints
 interaction (segid 1:7) 
 ((resi 97:118 or resi 122:170 or resi 174:193 or resi 197:205 or resi 209:213 or resi 217:241 or resi 245:333) and 
 segid A:G) weights vdw %.3f end 

interaction (segid 1:7 and resi 120) (segid 1:7 and resi 120)  weights * 1 end 
interaction (segid 1:7 and resi 172) (segid 1:7 and resi 172)  weights * 1 end 
interaction (segid 1:7 and resi 195) (segid 1:7 and resi 195)  weights * 1 end 
interaction (segid 1:7 and resi 207) (segid 1:7 and resi 207)  weights * 1 end 
interaction (segid 1:7 and resi 215) (segid 1:7 and resi 215)  weights * 1 end 
interaction (segid 1:7 and resi 243) (segid 1:7 and resi 243)  weights * 1 end 
 interaction (resi 97:108) (resi 97:108) weights * 1 vdw %.3f end
 interaction (resi 97:107) (resi 108:333) weights vdw 10 end 
end"""%(vdw_mtsl, vdw_nterm))

from ivm import IVM
dyn = IVM()
alpha = AtomSel("segid A:G")
dyn.fix("((resi 107:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N)))")
dyn.group("((resi 107:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N)))")
dyn.setBaseAtoms("not resname ANI")
protocol.torsionTopology(dyn)

init_t  = 3500.     # Need high temp and slow annealing to converge
InitialParams( rampedParams )
protocol.initDynamics(dyn, potList=potList, bathTemp=init_t, initVelocities=1, finalTime=80, numSteps=1000, printInterval=100)
constrainAlpha(vdw_mtsl=0.5, vdw_nterm=0.5)
dyn.run()

from simulationTools import AnnealIVM
cool = AnnealIVM(initTemp =init_t,
                 finalTemp=25,
                 tempStep =200,
                 ivm=dyn,
                 extraCommands="constrainAlpha()",
                 rampedParams = rampedParams)

InitialParams( rampedParams )
protocol.initDynamics(dyn,
                          potList=potList,
                          numSteps=2000,       #at each temp: 100 steps or
                          finalTime=3.0 ,       # .2ps, whichever is less
                          printInterval=100)

constrainAlpha(vdw_mtsl=1, vdw_nterm=1)
cool.run()

constrainAlpha(vdw_mtsl=1, vdw_nterm=1)
protocol.initMinimize(dyn, potList=potList, numSteps=500, printInterval=10)
constrainAlpha(vdw_mtsl=1, vdw_nterm=1)
dyn.run()

# This is for cartesian step (annealing + minimisation)
# Note that the parameters stay at their final value from the previous step
# Apart from dihedral angles, which stay at 20
potList['CDIH'].setScale(20)
minc = IVM()
protocol.initMinimize(minc)
protocol.cartesianTopology(minc)
minc.fix("((resi 107:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N)))")
minc.group("((resi 107:333 and segid A:G) or (segid 1:7 and (name CA or name C or name N)))")
minc.setBaseAtoms("not resname ANI")
cart_cool = AnnealIVM(initTemp =600,
                      finalTemp=25,
                      tempStep =50,
                      ivm=minc,
                      extraCommands="constrainAlpha(vdw_mtsl=1, vdw_nterm=1)")
protocol.initDynamics(minc,
                          potList=potList,
                          numSteps=2000,
                          finalTime=1.0,
                          printInterval=100)
constrainAlpha(vdw_mtsl=1, vdw_nterm=1)
cart_cool.run()
constrainAlpha(vdw_mtsl=1, vdw_nterm=1)
protocol.initMinimize(minc,
                          numSteps=1000, 
                          potList=potList,
                          dEPred=10,
                          printInterval=50)
constrainAlpha(vdw_mtsl=1, vdw_nterm=1)
minc.run()

# Analyse all the parameters of the model
for p in potList:
    print analyze(p)

xc("write psf output= input/min.spinlabel.psf end")
xc("write coor output = input/min.spinlabel.pdb end")




